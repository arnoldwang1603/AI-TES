"""V8: frozen v7 LSTM backbone plus a gated temporal residual TCN adapter.

The backbone remains the validated five-layer ThermalLSTM.  The adapter sees
only backbone predictions, known forcing, and initial conditions; it never sees
test labels. Candidate selection and per-output adapter gains use validation data;
the 250-case test set is evaluated only after the best validation checkpoint is
fixed.
"""

from __future__ import annotations

import argparse
from dataclasses import asdict
import json
from pathlib import Path
import time

import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F
from torch import nn
from torch.amp import GradScaler, autocast
from torch.utils.data import ConcatDataset, DataLoader, TensorDataset

import Final_LSTM_data522_v6 as v6
import Final_LSTM_data522_v7 as v7


ROOT = Path(__file__).resolve().parent
BASE_CHECKPOINT = ROOT / "Final_LSTM_data522_v7_result" / "best_v7.pth"
RESULT_DIR = ROOT / "Final_LSTM_data522_v8_result"
FEATURE_SIZE = 17


class CausalConv1d(nn.Conv1d):
    def __init__(self, channels: int, kernel_size: int, dilation: int):
        super().__init__(
            channels, channels, kernel_size,
            padding=(kernel_size - 1) * dilation,
            dilation=dilation,
        )
        self.trim = (kernel_size - 1) * dilation

    def forward(self, values: torch.Tensor) -> torch.Tensor:
        output = super().forward(values)
        return output[..., :-self.trim] if self.trim else output


class GatedCausalBlock(nn.Module):
    def __init__(self, channels: int, dilation: int, dropout: float):
        super().__init__()
        self.norm = nn.GroupNorm(1, channels)
        self.filter_conv = CausalConv1d(channels, 3, dilation)
        self.gate_conv = CausalConv1d(channels, 3, dilation)
        self.mix = nn.Conv1d(channels, channels, 1)
        self.dropout = nn.Dropout(dropout)

    def forward(self, values: torch.Tensor) -> torch.Tensor:
        normalized = self.norm(values)
        update = torch.tanh(self.filter_conv(normalized)) * torch.sigmoid(
            self.gate_conv(normalized)
        )
        return values + self.dropout(self.mix(update))


class ResidualTCNAdapter(nn.Module):
    def __init__(
        self,
        feature_size: int = FEATURE_SIZE,
        channels: int = 40,
        dilations: tuple[int, ...] = (1, 2, 4, 8, 16, 32),
        dropout: float = 0.05,
        max_correction: float = 0.08,
    ):
        super().__init__()
        self.max_correction = max_correction
        self.input_projection = nn.Conv1d(feature_size, channels, 1)
        self.blocks = nn.ModuleList(
            GatedCausalBlock(channels, dilation, dropout) for dilation in dilations
        )
        self.output_norm = nn.GroupNorm(1, channels)
        self.output_head = nn.Conv1d(channels, 3, 1)
        # Start exactly at the v7 prediction, then learn a bounded residual.
        nn.init.zeros_(self.output_head.weight)
        nn.init.zeros_(self.output_head.bias)

    def forward(self, features: torch.Tensor) -> torch.Tensor:
        values = self.input_projection(features.transpose(1, 2))
        for block in self.blocks:
            values = block(values)
        correction = self.output_head(F.gelu(self.output_norm(values))).transpose(1, 2)
        return self.max_correction * torch.tanh(correction)


def build_features(
    inputs: torch.Tensor,
    base_predictions: torch.Tensor,
    initial_conditions: torch.Tensor,
) -> torch.Tensor:
    """Build causal adapter inputs in normalized coordinates."""
    known = inputs[:, :, [0, 3, 5]]  # time, input temperature, convection
    prediction_delta = torch.diff(base_predictions, dim=1, prepend=base_predictions[:, :1])
    forcing = inputs[:, :, [3, 5]]
    forcing_delta = torch.diff(forcing, dim=1, prepend=forcing[:, :1])
    initial = initial_conditions.unsqueeze(1).expand(-1, inputs.size(1), -1)
    phase = known[:, :, :1]
    periodic = torch.cat([torch.sin(torch.pi * phase), torch.cos(torch.pi * phase)], dim=-1)
    return torch.cat(
        [base_predictions, known, initial, prediction_delta, forcing_delta, periodic], dim=-1
    )


@torch.inference_mode()
def collect_backbone_predictions(model, dfs, scaler, device, label: str):
    datasets = v6.make_datasets(dfs, scaler)
    loader = DataLoader(
        ConcatDataset(datasets), batch_size=32, shuffle=False, num_workers=0,
        pin_memory=device.type == "cuda",
    )
    features, base_predictions, targets = [], [], []
    done = 0
    for batch in loader:
        inputs, target, _, initial, *_ = batch
        inputs = inputs.to(device, non_blocking=True)
        initial = initial.to(device, non_blocking=True)
        base = v6.autoregressive_rollout(model, inputs, initial)
        features.append(build_features(inputs, base, initial).cpu())
        base_predictions.append(base.cpu())
        targets.append(target.cpu())
        done += inputs.size(0)
        if done % 160 == 0 or done == len(datasets):
            print(f"Backbone cache {label}: {done}/{len(datasets)}", flush=True)
    return torch.cat(features), torch.cat(base_predictions), torch.cat(targets)


def per_case_metrics(predicted_scaled, actual_scaled, scaler) -> tuple[v6.Metrics, pd.DataFrame]:
    predicted_c = v6.scaled_to_celsius(predicted_scaled, scaler).cpu().numpy()
    actual_c = v6.scaled_to_celsius(actual_scaled, scaler).cpu().numpy()
    rows = [asdict(v6._case_metric(actual, predicted)) for actual, predicted in zip(actual_c, predicted_c)]
    frame = pd.DataFrame(rows)
    means = frame.mean()
    metric = v6.Metrics(**{name: float(means[name]) for name in v6.Metrics.__dataclass_fields__})
    return metric, frame


@torch.inference_mode()
def adapter_predictions(adapter, features, base, device, batch_size=32):
    adapter.eval()
    loader = DataLoader(TensorDataset(features, base), batch_size=batch_size, shuffle=False)
    outputs = []
    for batch_features, batch_base in loader:
        batch_features = batch_features.to(device, non_blocking=True)
        batch_base = batch_base.to(device, non_blocking=True)
        outputs.append((batch_base + adapter(batch_features)).cpu())
    return torch.cat(outputs)


def scaled_loss(prediction, target, correction, time_feature):
    time_weight = 1.0 + 0.75 * time_feature.square()
    error = torch.abs(prediction - target) * time_weight
    mae = error.mean()
    robust = F.smooth_l1_loss(prediction, target, beta=0.004)
    slope = F.smooth_l1_loss(
        prediction[:, 1:] - prediction[:, :-1],
        target[:, 1:] - target[:, :-1],
        beta=0.001,
    )
    late = torch.abs(prediction[:, -360:] - target[:, -360:]).mean()
    regularizer = correction.square().mean()
    return 0.58 * mae + 0.16 * robust + 0.10 * slope + 0.12 * late + 0.04 * regularizer


def choose_output_gains(base, corrected, target, scaler) -> list[float]:
    correction = corrected - base
    grid = np.arange(0.25, 1.51, 0.05)
    selected = []
    for output_index in range(3):
        best = (float("inf"), 1.0)
        for gain in grid:
            candidate = base[:, :, output_index] + float(gain) * correction[:, :, output_index]
            # Scaling is affine, so normalized MAE and Celsius MAE have the same ordering.
            score = float(torch.mean(torch.abs(candidate - target[:, :, output_index])))
            if score < best[0]:
                best = (score, float(gain))
        selected.append(best[1])
    return selected


def apply_gains(base, corrected, gains):
    gain_tensor = torch.as_tensor(gains, device=base.device, dtype=base.dtype).view(1, 1, 3)
    return base + gain_tensor * (corrected - base)


def train_adapter(args, train_cache, val_cache, scaler, device):
    train_features, train_base, train_targets = train_cache
    val_features, val_base, val_targets = val_cache
    adapter = ResidualTCNAdapter(channels=args.channels, dropout=args.dropout).to(device)
    optimizer = torch.optim.AdamW(adapter.parameters(), lr=args.lr, weight_decay=2e-5)
    amp_scaler = GradScaler(device.type, enabled=device.type == "cuda")
    loader = DataLoader(
        TensorDataset(train_features, train_base, train_targets),
        batch_size=args.batch_size, shuffle=True, num_workers=0,
        pin_memory=device.type == "cuda",
    )
    baseline_metric, _ = per_case_metrics(val_base, val_targets, scaler)
    v6.print_metric("v7 validation baseline", baseline_metric)
    best = {"mae": float("inf"), "epoch": 0, "state": None, "gains": [1.0] * 3}
    history = []
    patience = 0
    for epoch in range(1, args.epochs + 1):
        adapter.train()
        running = 0.0
        start = time.perf_counter()
        for features, base, target in loader:
            features = features.to(device, non_blocking=True)
            base = base.to(device, non_blocking=True)
            target = target.to(device, non_blocking=True)
            optimizer.zero_grad(set_to_none=True)
            with autocast(device.type, enabled=device.type == "cuda"):
                correction = adapter(features)
                prediction = base + correction
                loss = scaled_loss(prediction, target, correction, features[:, :, 3:4])
            amp_scaler.scale(loss).backward()
            amp_scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(adapter.parameters(), 1.0)
            amp_scaler.step(optimizer)
            amp_scaler.update()
            running += float(loss.item())

        raw_validation = adapter_predictions(adapter, val_features, val_base, device)
        gains = choose_output_gains(val_base, raw_validation, val_targets, scaler)
        validation = apply_gains(val_base, raw_validation, gains)
        metric, _ = per_case_metrics(validation, val_targets, scaler)
        elapsed = time.perf_counter() - start
        row = {
            "epoch": epoch, "train_loss": running / len(loader),
            "validation_mean_mae_c": metric.mean_mae,
            "validation_mean_rmse_c": metric.mean_rmse,
            "validation_mean_r2": metric.mean_r2,
            "gain_inner": gains[0], "gain_outer": gains[1], "gain_avg": gains[2],
            "seconds": elapsed,
        }
        history.append(row)
        print(
            f"Epoch {epoch:02d}: loss={row['train_loss']:.6f} "
            f"val_MAE={metric.mean_mae:.6f} val_RMSE={metric.mean_rmse:.6f} "
            f"gains={gains} ({elapsed:.1f}s)", flush=True,
        )
        if metric.mean_mae < best["mae"] - 1e-5:
            best = {
                "mae": metric.mean_mae, "epoch": epoch,
                "state": {key: value.detach().cpu().clone() for key, value in adapter.state_dict().items()},
                "gains": gains,
            }
            patience = 0
        else:
            patience += 1
        if patience >= args.patience:
            print(f"Early stop after {patience} non-improving epochs")
            break

    pd.DataFrame(history).to_csv(RESULT_DIR / "training_history.csv", index=False)
    adapter.load_state_dict(best["state"])
    return adapter, best, baseline_metric


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--epochs", type=int, default=12)
    parser.add_argument("--patience", type=int, default=4)
    parser.add_argument("--batch-size", type=int, default=16)
    parser.add_argument("--channels", type=int, default=40)
    parser.add_argument("--dropout", type=float, default=0.05)
    parser.add_argument("--lr", type=float, default=7e-4)
    args = parser.parse_args()

    RESULT_DIR.mkdir(parents=True, exist_ok=True)
    v6.seed_everything(42)
    device = v6.select_device("auto")
    print(f"Device: {device}")
    train_dfs, val_dfs, test_dfs, scaler, _ = v6.load_project_data()
    clean_train = [(frame, name) for frame, name in train_dfs if not v7.severe_relation_anomaly(frame)[0]]
    clean_test = [(frame, name) for frame, name in test_dfs if not v7.severe_relation_anomaly(frame)[0]]
    print(f"Train trajectories after severe-anomaly quarantine: {len(clean_train)}")

    backbone = v6.build_model(device, BASE_CHECKPOINT)
    backbone.eval()
    train_cache = collect_backbone_predictions(backbone, clean_train, scaler, device, "train")
    val_cache = collect_backbone_predictions(backbone, val_dfs, scaler, device, "validation")
    adapter, best, baseline_val = train_adapter(args, train_cache, val_cache, scaler, device)
    print(f"Selected epoch {best['epoch']} with validation MAE {best['mae']:.6f}")

    package = {
        "base_state_dict": backbone.state_dict(),
        "adapter_state_dict": adapter.state_dict(),
        "adapter_config": {
            "feature_size": FEATURE_SIZE, "channels": args.channels,
            "dilations": [1, 2, 4, 8, 16, 32], "dropout": args.dropout,
            "max_correction": 0.08,
        },
        "output_gains_model_order_inner_outer_avg": best["gains"],
        "base_checkpoint": str(BASE_CHECKPOINT.resolve()),
        "self_contained": True,
        "selected_epoch": best["epoch"],
    }
    candidate_path = RESULT_DIR / "candidate_v8_adapter.pth"
    torch.save(package, candidate_path)

    test_features, test_base, test_targets = collect_backbone_predictions(
        backbone, test_dfs, scaler, device, "test"
    )
    raw_test = adapter_predictions(adapter, test_features, test_base, device)
    test_prediction = apply_gains(test_base, raw_test, best["gains"])
    baseline_full, baseline_rows = per_case_metrics(test_base, test_targets, scaler)
    candidate_full, candidate_rows = per_case_metrics(test_prediction, test_targets, scaler)

    clean_indices = [index for index, (frame, _) in enumerate(test_dfs) if not v7.severe_relation_anomaly(frame)[0]]
    baseline_clean, _ = per_case_metrics(test_base[clean_indices], test_targets[clean_indices], scaler)
    candidate_clean, _ = per_case_metrics(test_prediction[clean_indices], test_targets[clean_indices], scaler)
    v6.print_metric("v7 full test", baseline_full)
    v6.print_metric("v8 candidate full test", candidate_full)
    v6.print_metric("v7 clean test", baseline_clean)
    v6.print_metric("v8 candidate clean test", candidate_clean)

    names = [name for _, name in test_dfs]
    baseline_rows.insert(0, "Case", names)
    candidate_rows.insert(0, "Case", names)
    baseline_rows.to_csv(RESULT_DIR / "v7_full_test_metrics.csv", index=False, float_format="%.6f")
    candidate_rows.to_csv(RESULT_DIR / "candidate_v8_full_test_metrics.csv", index=False, float_format="%.6f")

    promoted = (
        candidate_full.mean_mae < baseline_full.mean_mae
        and candidate_full.mean_rmse < baseline_full.mean_rmse
        and candidate_clean.mean_mae < baseline_clean.mean_mae
    )
    if promoted:
        best_path = RESULT_DIR / "best_v8.pth"
        torch.save(package, best_path)
        print(f"PROMOTED: {best_path}")
    else:
        print("NOT PROMOTED: v7 remains the official best")

    result = {
        "architecture": "v7 five-layer LSTM + gated residual TCN with full-trajectory normalization",
        "base_checkpoint": str(BASE_CHECKPOINT.resolve()),
        "candidate_checkpoint": str(candidate_path.resolve()),
        "promoted": promoted,
        "selected_epoch": best["epoch"],
        "output_gains_model_order_inner_outer_avg": best["gains"],
        "validation": {
            "v7": {**asdict(baseline_val), "mean_mae": baseline_val.mean_mae,
                   "mean_rmse": baseline_val.mean_rmse, "mean_r2": baseline_val.mean_r2},
            "v8": {"mean_mae": best["mae"]},
        },
        "full_test": {
            "v7": {**asdict(baseline_full), "mean_mae": baseline_full.mean_mae,
                   "mean_rmse": baseline_full.mean_rmse, "mean_r2": baseline_full.mean_r2},
            "v8": {**asdict(candidate_full), "mean_mae": candidate_full.mean_mae,
                   "mean_rmse": candidate_full.mean_rmse, "mean_r2": candidate_full.mean_r2},
        },
        "clean_test": {
            "v7": {**asdict(baseline_clean), "mean_mae": baseline_clean.mean_mae,
                   "mean_rmse": baseline_clean.mean_rmse, "mean_r2": baseline_clean.mean_r2},
            "v8": {**asdict(candidate_clean), "mean_mae": candidate_clean.mean_mae,
                   "mean_rmse": candidate_clean.mean_rmse, "mean_r2": candidate_clean.mean_r2},
        },
    }
    with open(RESULT_DIR / "experiment_result.json", "w", encoding="utf-8") as handle:
        json.dump(result, handle, indent=2)


if __name__ == "__main__":
    main()
