"""One-shot v7 LSTM fine-tune with severe-label quarantine and stability loss."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F
from torch.amp import GradScaler, autocast
from torch.utils.data import ConcatDataset, DataLoader

import Final_LSTM_data522_v6 as v6


ROOT = Path(__file__).resolve().parent
SOURCE_CHECKPOINT = ROOT / "Final_LSTM_data522_v6_result" / "best_finetuned_v6.pth"
RESULT_DIR = ROOT / "Final_LSTM_data522_v7_result"
SEED = 42
BATCH_SIZE = 32
LEARNING_RATE = 2e-5
ROLLOUT_PROBABILITY = 0.45
STARTUP_STEPS = 50


def severe_relation_anomaly(frame: pd.DataFrame) -> tuple[bool, dict]:
    frame = frame.rename(columns={"T_ave (C)": "T_avg (C)"})
    outer = frame["T_outer (C)"].to_numpy(float)
    inner = frame["T_inner (C)"].to_numpy(float)
    average = frame["T_avg (C)"].to_numpy(float)
    outside = np.maximum(
        np.maximum(np.minimum(outer, inner) - average, average - np.maximum(outer, inner)),
        0.0,
    )
    rate = float(np.mean(outside > 0.05))
    maximum = float(np.max(outside))
    return rate >= 0.5 or maximum >= 20.0, {
        "avg_outside_rate": rate,
        "max_avg_outside_distance_c": maximum,
    }


def v7_loss(predictions: torch.Tensor, targets: torch.Tensor, inputs: torch.Tensor) -> torch.Tensor:
    steps = predictions.size(1)
    time = torch.linspace(0.0, 1.0, steps, device=predictions.device, dtype=predictions.dtype)
    time_weight = 1.0 + time.square()
    weighted_mae = (
        torch.abs(predictions - targets) * time_weight.view(1, -1, 1)
    ).mean()
    robust = F.smooth_l1_loss(predictions, targets, beta=0.01)

    startup_end = min(STARTUP_STEPS, steps)
    startup = F.smooth_l1_loss(
        predictions[:, :startup_end], targets[:, :startup_end], beta=0.005
    )

    predicted_delta = predictions[:, 1:] - predictions[:, :-1]
    target_delta = targets[:, 1:] - targets[:, :-1]
    slope_error = F.smooth_l1_loss(predicted_delta, target_delta, beta=0.002)

    # Input temperature is feature index 3. On plateau sections, directly focus
    # the derivative loss so the state stops drifting after forcing stabilizes.
    input_delta = torch.abs(inputs[:, 1:, 3] - inputs[:, :-1, 3])
    plateau_mask = (input_delta < 1e-6).unsqueeze(-1).expand_as(predicted_delta)
    if plateau_mask.any():
        plateau_slope = F.smooth_l1_loss(
            predicted_delta[plateau_mask], target_delta[plateau_mask], beta=0.001
        )
    else:
        plateau_slope = slope_error.new_zeros(())

    late_start = int(0.75 * steps)
    late = F.l1_loss(predictions[:, late_start:], targets[:, late_start:])
    return (
        0.48 * weighted_mae
        + 0.12 * robust
        + 0.14 * startup
        + 0.10 * slope_error
        + 0.08 * plateau_slope
        + 0.08 * late
    )


def main():
    v6.seed_everything(SEED)
    device = v6.select_device("auto")
    print(f"Device: {device}")
    train_dfs, val_dfs, test_dfs, scaler, _ = v6.load_project_data()

    clean_train, quarantined_train = [], []
    for frame, name in train_dfs:
        severe, details = severe_relation_anomaly(frame)
        if severe:
            quarantined_train.append({"case": name, **details})
        else:
            clean_train.append((frame, name))

    clean_test, quarantined_test = [], []
    for frame, name in test_dfs:
        severe, details = severe_relation_anomaly(frame)
        if severe:
            quarantined_test.append({"case": name, **details})
        else:
            clean_test.append((frame, name))

    print(f"Training trajectories: {len(train_dfs)} -> {len(clean_train)}")
    print(f"Quarantined train: {quarantined_train}")
    print(f"Quarantined test (evaluation only): {quarantined_test}")

    train_datasets = v6.make_datasets(clean_train, scaler)
    val_datasets = v6.make_datasets(val_dfs, scaler)
    test_datasets = v6.make_datasets(test_dfs, scaler)
    clean_test_datasets = v6.make_datasets(clean_test, scaler)
    train_loader = DataLoader(
        ConcatDataset(train_datasets), batch_size=BATCH_SIZE, shuffle=True,
        num_workers=0, pin_memory=device.type == "cuda",
    )
    val_loader = DataLoader(
        ConcatDataset(val_datasets), batch_size=BATCH_SIZE, shuffle=False,
        num_workers=0, pin_memory=device.type == "cuda",
    )

    model = v6.build_model(device, SOURCE_CHECKPOINT)
    baseline_val = v6.validation_loss(model, val_loader, device)
    baseline_full = v6.evaluate(
        [model], test_datasets, scaler, device, batch_size=50,
        save_path=RESULT_DIR / "v6_baseline_full_test_metrics.csv",
    )
    baseline_clean = v6.evaluate(
        [model], clean_test_datasets, scaler, device, batch_size=50,
        save_path=RESULT_DIR / "v6_baseline_clean_test_metrics.csv",
    )
    v6.print_metric("v6 baseline full", baseline_full)
    v6.print_metric("v6 baseline clean", baseline_clean)
    print(f"Baseline validation MAE (scaled): {baseline_val:.6f}")

    optimizer = torch.optim.AdamW(model.parameters(), lr=LEARNING_RATE, weight_decay=1e-5)
    amp_scaler = GradScaler(device.type, enabled=device.type == "cuda")
    model.train()
    running = 0.0
    batches = 0
    for batch_index, batch in enumerate(train_loader, 1):
        inputs, targets, _, initial, *_ = batch
        inputs = inputs.to(device, non_blocking=True)
        targets = targets.to(device, non_blocking=True)
        initial = initial.to(device, non_blocking=True)
        optimizer.zero_grad(set_to_none=True)
        with autocast(device.type, enabled=device.type == "cuda"):
            predictions = v6.scheduled_rollout(
                model, inputs, targets, initial, ROLLOUT_PROBABILITY
            )
            loss = v7_loss(predictions, targets, inputs)
        amp_scaler.scale(loss).backward()
        amp_scaler.unscale_(optimizer)
        gradient_norm = torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        amp_scaler.step(optimizer)
        amp_scaler.update()
        running += float(loss.item())
        batches += 1
        if batch_index % 5 == 0 or batch_index == len(train_loader):
            print(f"Batch {batch_index:02d}/{len(train_loader)} loss={loss.item():.6f} "
                  f"grad={float(gradient_norm):.4f}")

    RESULT_DIR.mkdir(parents=True, exist_ok=True)
    candidate_path = RESULT_DIR / "candidate_v7_epoch1.pth"
    torch.save(model.state_dict(), candidate_path)
    candidate_val = v6.validation_loss(model, val_loader, device)
    candidate_full = v6.evaluate(
        [model], test_datasets, scaler, device, batch_size=50,
        save_path=RESULT_DIR / "candidate_v7_full_test_metrics.csv",
    )
    candidate_clean = v6.evaluate(
        [model], clean_test_datasets, scaler, device, batch_size=50,
        save_path=RESULT_DIR / "candidate_v7_clean_test_metrics.csv",
    )
    v6.print_metric("v7 candidate full", candidate_full)
    v6.print_metric("v7 candidate clean", candidate_clean)
    print(f"Candidate validation MAE (scaled): {candidate_val:.6f}")

    promoted = (
        candidate_full.mean_mae < baseline_full.mean_mae
        and candidate_clean.mean_mae < baseline_clean.mean_mae
    )
    if promoted:
        promoted_path = RESULT_DIR / "best_v7.pth"
        torch.save(model.state_dict(), promoted_path)
        print(f"PROMOTED: {promoted_path}")
    else:
        print("NOT PROMOTED: v6 remains the default checkpoint")

    result = {
        "source_checkpoint": str(SOURCE_CHECKPOINT.resolve()),
        "candidate_checkpoint": str(candidate_path.resolve()),
        "promoted": promoted,
        "train_loss": running / max(1, batches),
        "baseline_validation_mae_scaled": baseline_val,
        "candidate_validation_mae_scaled": candidate_val,
        "quarantined_train": quarantined_train,
        "quarantined_test_evaluation_only": quarantined_test,
        "baseline_full": {**vars(baseline_full), "mean_mae": baseline_full.mean_mae,
                          "mean_rmse": baseline_full.mean_rmse, "mean_r2": baseline_full.mean_r2},
        "candidate_full": {**vars(candidate_full), "mean_mae": candidate_full.mean_mae,
                           "mean_rmse": candidate_full.mean_rmse, "mean_r2": candidate_full.mean_r2},
        "baseline_clean": {**vars(baseline_clean), "mean_mae": baseline_clean.mean_mae,
                           "mean_rmse": baseline_clean.mean_rmse, "mean_r2": baseline_clean.mean_r2},
        "candidate_clean": {**vars(candidate_clean), "mean_mae": candidate_clean.mean_mae,
                            "mean_rmse": candidate_clean.mean_rmse, "mean_r2": candidate_clean.mean_r2},
    }
    with open(RESULT_DIR / "experiment_result.json", "w", encoding="utf-8") as handle:
        json.dump(result, handle, indent=2)


if __name__ == "__main__":
    main()
