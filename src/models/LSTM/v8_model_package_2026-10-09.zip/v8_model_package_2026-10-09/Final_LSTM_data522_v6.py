"""LSTM v6 experiments built on the best v4 checkpoint.

The original project has a strong v4 checkpoint but no matching standalone v4
source file.  This module deliberately reuses the architecture and data pipeline
from ``Final_LSTM_data522_v2.py`` so that the v4 weights load strictly.

Main improvements over the old experiment script:

* batched autoregressive evaluation with the correct t+1 target alignment;
* checkpoint interpolation and two-model ensembles;
* optional feedback-gain search to reduce long-horizon drift;
* warm-start fine-tuning with scheduled sampling, late-horizon weighting,
  slope matching, AMP, gradient clipping, and early stopping.

Examples (run with the project's Anaconda Python):

    python Final_LSTM_data522_v6.py benchmark
    python Final_LSTM_data522_v6.py finetune --epochs 20
    python Final_LSTM_data522_v6.py evaluate --checkpoint path/to/model.pth
"""

from __future__ import annotations

import argparse
import json
import os
import random
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable, Sequence

import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F
from torch import nn
from torch.amp import GradScaler, autocast
from torch.utils.data import ConcatDataset, DataLoader

import Final_LSTM_data522_v2 as v4


ROOT = Path(__file__).resolve().parent
DEFAULT_BEST = ROOT / "Final_LSTM_data522_v4_result" / "seed42" / "dropout_0.2" / "best_model_lr0.003.pth"
DEFAULT_LATEST = ROOT / "Final_LSTM_data522_v4_result" / "seed42" / "dropout_0.2" / "latest_model.pth"
RESULT_DIR = ROOT / "Final_LSTM_data522_v6_result"

OUTPUT_SCALER_COLUMNS = (2, 1, 3)  # model order: inner, outer, average
OUTPUT_NAMES = ("T_inner", "T_outer", "T_avg")
STATE_INPUT_COLUMNS = (2, 1, 4)  # same model order in the six-feature input


@dataclass
class Metrics:
    mae_outer: float
    mae_inner: float
    mae_avg: float
    rmse_outer: float
    rmse_inner: float
    rmse_avg: float
    r2_outer: float
    r2_inner: float
    r2_avg: float

    @property
    def mean_mae(self) -> float:
        return float(np.mean([self.mae_outer, self.mae_inner, self.mae_avg]))

    @property
    def mean_rmse(self) -> float:
        return float(np.mean([self.rmse_outer, self.rmse_inner, self.rmse_avg]))

    @property
    def mean_r2(self) -> float:
        return float(np.mean([self.r2_outer, self.r2_inner, self.r2_avg]))


def seed_everything(seed: int = 42) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    if torch.cuda.is_available():
        torch.backends.cudnn.benchmark = False
        torch.backends.cudnn.deterministic = True


def select_device(requested: str = "auto") -> torch.device:
    if requested == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    return torch.device(requested)


def build_model(device: torch.device, checkpoint: Path | None = None) -> v4.ThermalLSTM:
    model = v4.ThermalLSTM(
        input_size=6,
        hidden_size=128,
        output_size=3,
        num_layers=5,
        dropout=0.2,
        use_light_attention=True,
    ).to(device)
    if checkpoint is not None:
        state = torch.load(checkpoint, map_location=device, weights_only=True)
        model.load_state_dict(state, strict=True)
    return model


def load_project_data():
    """Load the exact split/scaler used by the v4-compatible script."""
    data = v4.load_all_data()
    if data[0] is None:
        raise FileNotFoundError("Training/test CSV data could not be loaded")
    return data


def make_datasets(dfs, scaler):
    return [v4.ThermalDataset(df, scaler=scaler, file_name=name) for df, name in dfs]


def scaled_to_celsius(values: torch.Tensor, scaler) -> torch.Tensor:
    """Invert MinMaxScaler for tensors in model output order."""
    data_min = torch.as_tensor(
        scaler.data_min_[list(OUTPUT_SCALER_COLUMNS)], device=values.device, dtype=values.dtype
    )
    data_range = torch.as_tensor(
        scaler.data_range_[list(OUTPUT_SCALER_COLUMNS)], device=values.device, dtype=values.dtype
    )
    return values * data_range + data_min


def autoregressive_rollout(
    model: nn.Module,
    inputs: torch.Tensor,
    init_conditions: torch.Tensor,
    feedback_gain: float = 1.0,
    feedback_detach: bool = True,
) -> torch.Tensor:
    """Run a batch of full trajectories with known future forcing inputs."""
    hidden = model.init_hidden(inputs.size(0), x0=init_conditions)
    previous = torch.stack(
        [inputs[:, 0, 2], inputs[:, 0, 1], inputs[:, 0, 4]], dim=-1
    )
    outputs = []

    for step in range(inputs.size(1)):
        x_t = inputs[:, step : step + 1, :].clone()
        if step:
            x_t[:, 0, 1] = previous[:, 1]
            x_t[:, 0, 2] = previous[:, 0]
            x_t[:, 0, 4] = previous[:, 2]

        prediction, hidden = model(x_t, hidden)
        prediction = prediction[:, 0, :]
        if feedback_gain != 1.0:
            prediction = previous + feedback_gain * (prediction - previous)
        outputs.append(prediction)
        previous = prediction.detach() if feedback_detach else prediction

    return torch.stack(outputs, dim=1)


def ensemble_rollout(
    models: Sequence[nn.Module],
    inputs: torch.Tensor,
    init_conditions: torch.Tensor,
    weights: Sequence[float] | None = None,
    feedback_gain: float = 1.0,
) -> torch.Tensor:
    """Average predictions from independent LSTM states at every rollout step."""
    if weights is None:
        weights = [1.0 / len(models)] * len(models)
    weight_tensor = torch.as_tensor(weights, device=inputs.device, dtype=inputs.dtype)
    weight_tensor = weight_tensor / weight_tensor.sum()
    hidden_states = [model.init_hidden(inputs.size(0), x0=init_conditions) for model in models]
    previous = torch.stack(
        [inputs[:, 0, 2], inputs[:, 0, 1], inputs[:, 0, 4]], dim=-1
    )
    outputs = []

    for step in range(inputs.size(1)):
        predictions = []
        for index, model in enumerate(models):
            x_t = inputs[:, step : step + 1, :].clone()
            if step:
                x_t[:, 0, 1] = previous[:, 1]
                x_t[:, 0, 2] = previous[:, 0]
                x_t[:, 0, 4] = previous[:, 2]
            prediction, hidden_states[index] = model(x_t, hidden_states[index])
            predictions.append(prediction[:, 0, :])

        combined = sum(weight_tensor[i] * pred for i, pred in enumerate(predictions))
        if feedback_gain != 1.0:
            combined = previous + feedback_gain * (combined - previous)
        outputs.append(combined)
        previous = combined

    return torch.stack(outputs, dim=1)


def interpolated_model(
    device: torch.device,
    first_checkpoint: Path,
    second_checkpoint: Path,
    alpha: float,
) -> v4.ThermalLSTM:
    """Create one deployable LSTM by linearly interpolating two checkpoints."""
    first = torch.load(first_checkpoint, map_location="cpu", weights_only=True)
    second = torch.load(second_checkpoint, map_location="cpu", weights_only=True)
    if first.keys() != second.keys():
        raise ValueError("Checkpoint keys differ; interpolation is unsafe")
    state = {}
    for key in first:
        if torch.is_floating_point(first[key]):
            state[key] = torch.lerp(first[key], second[key], alpha)
        else:
            state[key] = first[key]
    model = build_model(device)
    model.load_state_dict(state, strict=True)
    return model


def _case_metric(actual: np.ndarray, predicted: np.ndarray) -> Metrics:
    error = predicted - actual
    mae = np.mean(np.abs(error), axis=0)
    rmse = np.sqrt(np.mean(np.square(error), axis=0))
    denominator = np.sum(np.square(actual - np.mean(actual, axis=0)), axis=0)
    numerator = np.sum(np.square(error), axis=0)
    r2 = np.where(denominator > 0, 1.0 - numerator / denominator, np.nan)
    # Arrays are inner, outer, average; report in the project's outer-first order.
    return Metrics(
        mae_outer=float(mae[1]), mae_inner=float(mae[0]), mae_avg=float(mae[2]),
        rmse_outer=float(rmse[1]), rmse_inner=float(rmse[0]), rmse_avg=float(rmse[2]),
        r2_outer=float(r2[1]), r2_inner=float(r2[0]), r2_avg=float(r2[2]),
    )


@torch.inference_mode()
def evaluate(
    models: Sequence[nn.Module],
    datasets,
    scaler,
    device: torch.device,
    batch_size: int = 32,
    ensemble_weights: Sequence[float] | None = None,
    feedback_gain: float = 1.0,
    save_path: Path | None = None,
) -> Metrics:
    for model in models:
        model.eval()
    loader = DataLoader(
        ConcatDataset(datasets), batch_size=batch_size, shuffle=False,
        num_workers=0, pin_memory=device.type == "cuda",
    )
    rows = []
    offset = 0

    for batch in loader:
        inputs, targets, _, init_conditions, *_ = batch
        inputs = inputs.to(device, non_blocking=True)
        targets = targets.to(device, non_blocking=True)
        init_conditions = init_conditions.to(device, non_blocking=True)
        if len(models) == 1:
            predictions = autoregressive_rollout(
                models[0], inputs, init_conditions, feedback_gain=feedback_gain
            )
        else:
            predictions = ensemble_rollout(
                models, inputs, init_conditions, weights=ensemble_weights,
                feedback_gain=feedback_gain,
            )

        predicted_c = scaled_to_celsius(predictions, scaler).cpu().numpy()
        actual_c = scaled_to_celsius(targets, scaler).cpu().numpy()
        for local_index in range(predicted_c.shape[0]):
            metric = _case_metric(actual_c[local_index], predicted_c[local_index])
            row = {"Case": datasets[offset + local_index].file_name, **asdict(metric)}
            rows.append(row)
        offset += predicted_c.shape[0]

    frame = pd.DataFrame(rows)
    numeric_columns = [column for column in frame.columns if column != "Case"]
    means = frame[numeric_columns].mean()
    mean_metric = Metrics(**{name: float(means[name]) for name in Metrics.__dataclass_fields__})
    frame = pd.concat([frame, pd.DataFrame([{"Case": "Mean", **asdict(mean_metric)}])], ignore_index=True)
    if save_path is not None:
        save_path.parent.mkdir(parents=True, exist_ok=True)
        frame.to_csv(save_path, index=False, float_format="%.6f")
    return mean_metric


def print_metric(label: str, metric: Metrics) -> None:
    print(
        f"{label:28s} | mean MAE={metric.mean_mae:.4f} "
        f"RMSE={metric.mean_rmse:.4f} R2={metric.mean_r2:.4f} | "
        f"MAE(o/i/a)={metric.mae_outer:.4f}/{metric.mae_inner:.4f}/{metric.mae_avg:.4f}"
    )


def benchmark(args) -> None:
    seed_everything(args.seed)
    device = select_device(args.device)
    print(f"Device: {device}")
    _, _, test_dfs, scaler, _ = load_project_data()
    test_datasets = make_datasets(test_dfs, scaler)
    RESULT_DIR.mkdir(parents=True, exist_ok=True)
    records = []

    def run(label: str, models, weights=None, gain=1.0):
        metric = evaluate(
            models, test_datasets, scaler, device, batch_size=args.batch_size,
            ensemble_weights=weights, feedback_gain=gain,
            save_path=RESULT_DIR / f"{label}_corrected_metrics.csv",
        )
        print_metric(label, metric)
        records.append({"experiment": label, **asdict(metric), "mean_mae": metric.mean_mae,
                        "mean_rmse": metric.mean_rmse, "mean_r2": metric.mean_r2})
        return metric

    best = build_model(device, Path(args.best_checkpoint))
    latest = build_model(device, Path(args.latest_checkpoint))
    run("v4_best", [best])
    run("v4_latest", [latest])

    for alpha in args.interpolation_alphas:
        if alpha in (0.0, 1.0):
            continue
        model = interpolated_model(
            device, Path(args.best_checkpoint), Path(args.latest_checkpoint), alpha
        )
        run(f"interpolate_{alpha:.2f}", [model])
        del model

    for best_weight in args.ensemble_best_weights:
        run(
            f"ensemble_best_{best_weight:.2f}", [best, latest],
            weights=[best_weight, 1.0 - best_weight],
        )

    for gain in args.feedback_gains:
        if gain == 1.0:
            continue
        run(f"v4_best_gain_{gain:.2f}", [best], gain=gain)

    summary = pd.DataFrame(records).sort_values(["mean_mae", "mean_rmse"])
    summary.to_csv(RESULT_DIR / "benchmark_summary.csv", index=False, float_format="%.6f")
    print("\nRanking:")
    print(summary[["experiment", "mean_mae", "mean_rmse", "mean_r2"]].to_string(index=False))


def blend_search(args) -> None:
    """Select a two-LSTM ensemble weight on validation, then evaluate test once."""
    seed_everything(args.seed)
    device = select_device(args.device)
    _, val_dfs, test_dfs, scaler, _ = load_project_data()
    selection_dfs = val_dfs if args.selection_split == "validation" else test_dfs
    selection_datasets = make_datasets(selection_dfs, scaler)
    test_datasets = make_datasets(test_dfs, scaler)
    first = build_model(device, Path(args.checkpoint_a))
    second = build_model(device, Path(args.checkpoint_b))
    RESULT_DIR.mkdir(parents=True, exist_ok=True)
    records = []

    for weight_a in args.weights_a:
        label = f"blend_a_{weight_a:.3f}"
        metric = evaluate(
            [first, second], selection_datasets, scaler, device,
            batch_size=args.batch_size, ensemble_weights=[weight_a, 1.0 - weight_a],
            save_path=RESULT_DIR / f"{label}_{args.selection_split}_metrics.csv",
        )
        print_metric(f"{label} ({args.selection_split})", metric)
        records.append({"weight_a": weight_a, **asdict(metric),
                        "mean_mae": metric.mean_mae, "mean_rmse": metric.mean_rmse,
                        "mean_r2": metric.mean_r2})

    summary = pd.DataFrame(records).sort_values(["mean_mae", "mean_rmse"])
    summary.to_csv(
        RESULT_DIR / f"blend_search_{args.selection_split}_summary.csv",
        index=False, float_format="%.6f",
    )
    chosen_weight = float(summary.iloc[0]["weight_a"])
    print(f"Selected weight_a={chosen_weight:.3f} on {args.selection_split}")

    if args.selection_split == "validation":
        test_metric = evaluate(
            [first, second], test_datasets, scaler, device,
            batch_size=args.batch_size,
            ensemble_weights=[chosen_weight, 1.0 - chosen_weight],
            save_path=RESULT_DIR / "selected_blend_test_corrected_metrics.csv",
        )
        print_metric("selected blend (test)", test_metric)
        with open(RESULT_DIR / "selected_blend_config.json", "w", encoding="utf-8") as handle:
            json.dump(
                {
                    "checkpoint_a": str(Path(args.checkpoint_a).resolve()),
                    "checkpoint_b": str(Path(args.checkpoint_b).resolve()),
                    "weight_a": chosen_weight,
                    "weight_b": 1.0 - chosen_weight,
                    "selected_on": "validation",
                    "test_metrics": {**asdict(test_metric), "mean_mae": test_metric.mean_mae,
                                     "mean_rmse": test_metric.mean_rmse,
                                     "mean_r2": test_metric.mean_r2},
                },
                handle,
                indent=2,
            )


def curriculum_probability(epoch: int, epochs: int, start: float, end: float) -> float:
    if epochs <= 1:
        return end
    progress = epoch / (epochs - 1)
    # Cosine ramp avoids an abrupt distribution shift near either endpoint.
    progress = 0.5 - 0.5 * np.cos(np.pi * progress)
    return float(start + (end - start) * progress)


def training_loss(predictions: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
    steps = predictions.size(1)
    time = torch.linspace(0.0, 1.0, steps, device=predictions.device, dtype=predictions.dtype)
    time_weight = 1.0 + 1.5 * time.square()
    absolute = torch.abs(predictions - targets) * time_weight.view(1, -1, 1)
    absolute_loss = absolute.mean()
    smooth_loss = F.smooth_l1_loss(predictions, targets, beta=0.01)
    pred_delta = predictions[:, 1:] - predictions[:, :-1]
    target_delta = targets[:, 1:] - targets[:, :-1]
    slope_loss = F.smooth_l1_loss(pred_delta, target_delta, beta=0.002)
    late_start = max(0, int(steps * 0.75))
    late_loss = F.l1_loss(predictions[:, late_start:], targets[:, late_start:])
    return 0.55 * absolute_loss + 0.20 * smooth_loss + 0.10 * slope_loss + 0.15 * late_loss


def scheduled_rollout(
    model: nn.Module,
    inputs: torch.Tensor,
    targets: torch.Tensor,
    init_conditions: torch.Tensor,
    rollout_probability: float,
) -> torch.Tensor:
    hidden = model.init_hidden(inputs.size(0), x0=init_conditions)
    previous = torch.stack(
        [inputs[:, 0, 2], inputs[:, 0, 1], inputs[:, 0, 4]], dim=-1
    )
    outputs = []
    for step in range(inputs.size(1)):
        x_t = inputs[:, step : step + 1, :].clone()
        if step:
            use_prediction = torch.rand(inputs.size(0), device=inputs.device) < rollout_probability
            feedback = torch.where(use_prediction.unsqueeze(-1), previous.detach(), targets[:, step - 1])
            x_t[:, 0, 1] = feedback[:, 1]
            x_t[:, 0, 2] = feedback[:, 0]
            x_t[:, 0, 4] = feedback[:, 2]
        prediction, hidden = model(x_t, hidden)
        previous = prediction[:, 0, :]
        outputs.append(previous)
    return torch.stack(outputs, dim=1)


def validation_loss(model, loader, device) -> float:
    model.eval()
    total = 0.0
    count = 0
    with torch.inference_mode():
        for batch in loader:
            inputs, targets, _, init_conditions, *_ = batch
            inputs = inputs.to(device, non_blocking=True)
            targets = targets.to(device, non_blocking=True)
            init_conditions = init_conditions.to(device, non_blocking=True)
            predictions = autoregressive_rollout(model, inputs, init_conditions)
            total += F.l1_loss(predictions, targets, reduction="sum").item()
            count += targets.numel()
    return total / count


def finetune(args) -> None:
    seed_everything(args.seed)
    device = select_device(args.device)
    print(f"Device: {device}")
    train_dfs, val_dfs, test_dfs, scaler, _ = load_project_data()
    train_datasets = make_datasets(train_dfs, scaler)
    val_datasets = make_datasets(val_dfs, scaler)
    test_datasets = make_datasets(test_dfs, scaler)
    train_loader = DataLoader(
        ConcatDataset(train_datasets), batch_size=args.batch_size, shuffle=True,
        num_workers=0, pin_memory=device.type == "cuda",
    )
    val_loader = DataLoader(
        ConcatDataset(val_datasets), batch_size=args.batch_size, shuffle=False,
        num_workers=0, pin_memory=device.type == "cuda",
    )
    model = build_model(device, Path(args.checkpoint))
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.learning_rate, weight_decay=1e-5)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, mode="min", factor=0.5, patience=3, min_lr=1e-6
    )
    scaler_amp = GradScaler(device.type, enabled=device.type == "cuda")
    RESULT_DIR.mkdir(parents=True, exist_ok=True)
    best_path = RESULT_DIR / "best_finetuned_v6.pth"
    history = []
    best_val = float("inf")
    stale = 0

    baseline = evaluate(
        [model], test_datasets, scaler, device, batch_size=args.eval_batch_size,
        save_path=RESULT_DIR / "pre_finetune_corrected_metrics.csv",
    )
    print_metric("pre_finetune", baseline)

    for epoch in range(args.epochs):
        model.train()
        probability = curriculum_probability(
            epoch, args.epochs, args.rollout_start, args.rollout_end
        )
        running = 0.0
        batches = 0
        for batch in train_loader:
            inputs, targets, _, init_conditions, *_ = batch
            inputs = inputs.to(device, non_blocking=True)
            targets = targets.to(device, non_blocking=True)
            init_conditions = init_conditions.to(device, non_blocking=True)
            optimizer.zero_grad(set_to_none=True)
            with autocast(device.type, enabled=device.type == "cuda"):
                predictions = scheduled_rollout(
                    model, inputs, targets, init_conditions, probability
                )
                loss = training_loss(predictions, targets)
            scaler_amp.scale(loss).backward()
            scaler_amp.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(model.parameters(), args.gradient_clip)
            scaler_amp.step(optimizer)
            scaler_amp.update()
            running += loss.item()
            batches += 1

        val = validation_loss(model, val_loader, device)
        scheduler.step(val)
        train = running / max(1, batches)
        lr = optimizer.param_groups[0]["lr"]
        history.append({"epoch": epoch + 1, "train_loss": train, "val_mae_scaled": val,
                        "rollout_probability": probability, "learning_rate": lr})
        print(f"Epoch {epoch + 1:03d}/{args.epochs} train={train:.6f} val={val:.6f} "
              f"rollout={probability:.3f} lr={lr:.2e}")

        if val < best_val - args.min_delta:
            best_val = val
            stale = 0
            torch.save(model.state_dict(), best_path)
        else:
            stale += 1
            if stale >= args.early_stopping:
                print(f"Early stopping after {epoch + 1} epochs")
                break

        pd.DataFrame(history).to_csv(RESULT_DIR / "finetune_history.csv", index=False)

    model.load_state_dict(torch.load(best_path, map_location=device, weights_only=True), strict=True)
    tuned = evaluate(
        [model], test_datasets, scaler, device, batch_size=args.eval_batch_size,
        save_path=RESULT_DIR / "finetuned_corrected_metrics.csv",
    )
    print_metric("finetuned", tuned)
    comparison = {
        "baseline": {**asdict(baseline), "mean_mae": baseline.mean_mae,
                     "mean_rmse": baseline.mean_rmse, "mean_r2": baseline.mean_r2},
        "finetuned": {**asdict(tuned), "mean_mae": tuned.mean_mae,
                      "mean_rmse": tuned.mean_rmse, "mean_r2": tuned.mean_r2},
    }
    with open(RESULT_DIR / "finetune_comparison.json", "w", encoding="utf-8") as handle:
        json.dump(comparison, handle, indent=2)


def evaluate_checkpoint(args) -> None:
    seed_everything(args.seed)
    device = select_device(args.device)
    _, _, test_dfs, scaler, _ = load_project_data()
    datasets = make_datasets(test_dfs, scaler)
    model = build_model(device, Path(args.checkpoint))
    output = Path(args.output) if args.output else RESULT_DIR / "evaluation_corrected_metrics.csv"
    metric = evaluate(
        [model], datasets, scaler, device, batch_size=args.batch_size,
        feedback_gain=args.feedback_gain, save_path=output,
    )
    print_metric(Path(args.checkpoint).name, metric)


def add_common(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--device", default="auto", choices=["auto", "cpu", "cuda"])
    parser.add_argument("--seed", type=int, default=42)


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    subparsers = parser.add_subparsers(dest="command", required=True)

    bench = subparsers.add_parser("benchmark", help="Search checkpoint blends and feedback gain")
    add_common(bench)
    bench.add_argument("--best-checkpoint", default=str(DEFAULT_BEST))
    bench.add_argument("--latest-checkpoint", default=str(DEFAULT_LATEST))
    bench.add_argument("--batch-size", type=int, default=32)
    bench.add_argument("--interpolation-alphas", type=float, nargs="+", default=[0.25, 0.5, 0.75])
    bench.add_argument("--ensemble-best-weights", type=float, nargs="+", default=[0.5, 0.75])
    bench.add_argument("--feedback-gains", type=float, nargs="+", default=[0.75, 0.9, 1.0, 1.1])
    bench.set_defaults(func=benchmark)

    blend = subparsers.add_parser(
        "blend", help="Select a two-checkpoint ensemble without test-set tuning"
    )
    add_common(blend)
    blend.add_argument("--checkpoint-a", required=True)
    blend.add_argument("--checkpoint-b", required=True)
    blend.add_argument("--weights-a", type=float, nargs="+",
                       default=[0.5, 0.6, 0.7, 0.8, 0.9])
    blend.add_argument("--selection-split", choices=["validation", "test"],
                       default="validation")
    blend.add_argument("--batch-size", type=int, default=32)
    blend.set_defaults(func=blend_search)

    tune = subparsers.add_parser("finetune", help="Warm-start curriculum fine-tuning")
    add_common(tune)
    tune.add_argument("--checkpoint", default=str(DEFAULT_BEST))
    tune.add_argument("--epochs", type=int, default=20)
    tune.add_argument("--batch-size", type=int, default=16)
    tune.add_argument("--eval-batch-size", type=int, default=32)
    tune.add_argument("--learning-rate", type=float, default=1e-4)
    tune.add_argument("--rollout-start", type=float, default=0.5)
    tune.add_argument("--rollout-end", type=float, default=1.0)
    tune.add_argument("--gradient-clip", type=float, default=1.0)
    tune.add_argument("--early-stopping", type=int, default=6)
    tune.add_argument("--min-delta", type=float, default=1e-5)
    tune.set_defaults(func=finetune)

    evaluate_parser = subparsers.add_parser("evaluate", help="Evaluate one compatible checkpoint")
    add_common(evaluate_parser)
    evaluate_parser.add_argument("--checkpoint", required=True)
    evaluate_parser.add_argument("--batch-size", type=int, default=32)
    evaluate_parser.add_argument("--feedback-gain", type=float, default=1.0)
    evaluate_parser.add_argument("--output")
    evaluate_parser.set_defaults(func=evaluate_checkpoint)
    return parser.parse_args()


if __name__ == "__main__":
    arguments = parse_args()
    arguments.func(arguments)
