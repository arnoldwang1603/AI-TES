"""Export the official v8 per-case results and v7-v8 stability diagnostics."""

from __future__ import annotations

from dataclasses import asdict
import json
from pathlib import Path
import re

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import torch
from torch.utils.data import ConcatDataset, DataLoader

import Final_LSTM_data522_v6 as v6
import Final_LSTM_data522_v8 as v8


ROOT = Path(__file__).resolve().parent
CHECKPOINT = ROOT / "Final_LSTM_data522_v8_result" / "best_v8.pth"
RESULT_DIR = ROOT / "Final_LSTM_data522_v8_result"
PLOT_DIR = RESULT_DIR / "test_best_v8"
CSV_DIR = RESULT_DIR / "test_best_v8_csv"
SUMMARY_PATH = RESULT_DIR / "test_best_v8_summary.csv"
DIAGNOSTICS_PATH = RESULT_DIR / "curve_stability.json"
ERROR_PLOT_PATH = RESULT_DIR / "mean_error_over_time_v7_vs_v8.png"


def safe_stem(name: str) -> str:
    return re.sub(r'[<>:"/\\|?*]', "_", Path(name).stem).rstrip(". ")


def build_adapter(package, device):
    config = package["adapter_config"]
    adapter = v8.ResidualTCNAdapter(
        feature_size=config["feature_size"], channels=config["channels"],
        dilations=tuple(config["dilations"]), dropout=config["dropout"],
        max_correction=config["max_correction"],
    ).to(device)
    adapter.load_state_dict(package["adapter_state_dict"])
    adapter.eval()
    return adapter


def build_backbone(package, device):
    backbone = v6.build_model(device)
    if "base_state_dict" in package:
        backbone.load_state_dict(package["base_state_dict"], strict=True)
    else:
        state = torch.load(v8.BASE_CHECKPOINT, map_location=device, weights_only=True)
        backbone.load_state_dict(state, strict=True)
    backbone.eval()
    return backbone


def new_stability_accumulator(steps: int):
    return {
        "step_gt_0_5c": 0, "step_gt_1c": 0, "step_gt_2c": 0, "step_gt_5c": 0,
        "unexpected_gt_1c_actual_lt_0_5c": 0, "positive_raise_gt_1c": 0,
        "ordering_violations": 0, "ordering_total": 0,
        "absolute_steps": [], "error_sum_by_time": np.zeros(steps, dtype=np.float64),
        "error_count_by_time": 0,
    }


def update_stability(accumulator, prediction, actual):
    predicted_step = np.diff(prediction, axis=1)
    actual_step = np.diff(actual, axis=1)
    absolute_step = np.abs(predicted_step)
    accumulator["step_gt_0_5c"] += int(np.sum(absolute_step > 0.5))
    accumulator["step_gt_1c"] += int(np.sum(absolute_step > 1.0))
    accumulator["step_gt_2c"] += int(np.sum(absolute_step > 2.0))
    accumulator["step_gt_5c"] += int(np.sum(absolute_step > 5.0))
    accumulator["unexpected_gt_1c_actual_lt_0_5c"] += int(
        np.sum((absolute_step > 1.0) & (np.abs(actual_step) < 0.5))
    )
    accumulator["positive_raise_gt_1c"] += int(np.sum(predicted_step > 1.0))
    lower = np.minimum(prediction[:, :, 0], prediction[:, :, 1])
    upper = np.maximum(prediction[:, :, 0], prediction[:, :, 1])
    average = prediction[:, :, 2]
    accumulator["ordering_violations"] += int(
        np.sum((average < lower - 0.05) | (average > upper + 0.05))
    )
    accumulator["ordering_total"] += int(average.size)
    accumulator["absolute_steps"].append(absolute_step.reshape(-1))
    accumulator["error_sum_by_time"] += np.abs(prediction - actual).sum(axis=(0, 2))
    accumulator["error_count_by_time"] += prediction.shape[0] * prediction.shape[2]


def finish_stability(accumulator):
    step_values = np.concatenate(accumulator.pop("absolute_steps"))
    error_curve = accumulator.pop("error_sum_by_time") / accumulator.pop("error_count_by_time")
    ordering_total = accumulator.pop("ordering_total")
    ordering_violations = accumulator.pop("ordering_violations")
    steps = len(error_curve)
    quarters = np.array_split(error_curve, 4)
    result = {
        **accumulator,
        "ordering_violation_rate": ordering_violations / ordering_total,
        "predicted_step_p99_9_c": float(np.percentile(step_values, 99.9)),
        "mean_absolute_error_by_quarter_c": [float(part.mean()) for part in quarters],
    }
    return result, error_curve


@torch.inference_mode()
def main():
    v6.seed_everything(42)
    device = v6.select_device("auto")
    _, _, test_dfs, scaler, _ = v6.load_project_data()
    datasets = v6.make_datasets(test_dfs, scaler)
    loader = DataLoader(
        ConcatDataset(datasets), batch_size=32, shuffle=False, num_workers=0,
        pin_memory=device.type == "cuda",
    )
    package = torch.load(CHECKPOINT, map_location="cpu", weights_only=False)
    backbone = build_backbone(package, device)
    adapter = build_adapter(package, device)
    gains = torch.tensor(
        package["output_gains_model_order_inner_outer_avg"], device=device
    ).view(1, 1, 3)

    PLOT_DIR.mkdir(parents=True, exist_ok=True)
    CSV_DIR.mkdir(parents=True, exist_ok=True)
    summary_rows = []
    v7_stability = None
    v8_stability = None
    offset = 0

    for batch in loader:
        inputs, targets, _, initial, *_ = batch
        inputs = inputs.to(device, non_blocking=True)
        targets = targets.to(device, non_blocking=True)
        initial = initial.to(device, non_blocking=True)
        base = v6.autoregressive_rollout(backbone, inputs, initial)
        features = v8.build_features(inputs, base, initial)
        corrected = base + gains * adapter(features)
        base_c = v6.scaled_to_celsius(base, scaler).cpu().numpy()
        prediction_c = v6.scaled_to_celsius(corrected, scaler).cpu().numpy()
        actual_c = v6.scaled_to_celsius(targets, scaler).cpu().numpy()

        if v7_stability is None:
            v7_stability = new_stability_accumulator(prediction_c.shape[1])
            v8_stability = new_stability_accumulator(prediction_c.shape[1])
        update_stability(v7_stability, base_c, actual_c)
        update_stability(v8_stability, prediction_c, actual_c)

        for local_index in range(prediction_c.shape[0]):
            frame, case_name = test_dfs[offset + local_index]
            frame = frame.rename(columns={"T_ave (C)": "T_avg (C)"})
            target_frame = frame.iloc[1:].reset_index(drop=True)
            forcing = frame.iloc[:-1].reset_index(drop=True)
            prediction = prediction_c[local_index]
            actual = actual_c[local_index]
            count = min(len(prediction), len(target_frame), len(forcing))
            prediction, actual = prediction[:count], actual[:count]
            target_frame, forcing = target_frame.iloc[:count], forcing.iloc[:count]
            metric = v6._case_metric(actual, prediction)
            summary_rows.append({"Case": case_name, **asdict(metric)})

            output = pd.DataFrame({
                "Time (s)": target_frame["Time (s)"].to_numpy(float),
                "T_outer_Actual (C)": actual[:, 1], "T_inner_Actual (C)": actual[:, 0],
                "T_avg_Actual (C)": actual[:, 2], "T_outer_Pred (C)": prediction[:, 1],
                "T_inner_Pred (C)": prediction[:, 0], "T_avg_Pred (C)": prediction[:, 2],
                "Input_T_Used (C)": forcing["Input Temperature (C)"].to_numpy(float),
                "Convection_Used (W/m2C)": forcing["Convection (W/m2C)"].to_numpy(float),
            })
            stem = safe_stem(case_name)
            output.to_csv(CSV_DIR / f"{stem}_predictions.csv", index=False, float_format="%.6f")

            time_values = output["Time (s)"].to_numpy()
            fig, axis = plt.subplots(figsize=(15, 8))
            for color, key, label in [
                ("b", "outer", "T_outer"), ("r", "inner", "T_inner"), ("g", "avg", "T_avg")
            ]:
                axis.plot(time_values, output[f"T_{key}_Actual (C)"], color + "-", linewidth=2, label=f"{label} Actual")
                mae = getattr(metric, f"mae_{key}")
                rmse = getattr(metric, f"rmse_{key}")
                r2 = getattr(metric, f"r2_{key}")
                axis.plot(time_values, output[f"T_{key}_Pred (C)"], color + "--", linewidth=1.8,
                          label=f"{label} Pred (MAE={mae:.2f}, RMSE={rmse:.2f}, R2={r2:.3f})")
            axis.plot(time_values, output["Input_T_Used (C)"], "k-.", linewidth=1.5, label="Input Temperature Used")
            axis.set(xlabel="Time (s)", ylabel="Temperature (C)", title=f"V8 temperature prediction - {case_name}")
            axis.grid(True, alpha=0.35)
            axis.legend(bbox_to_anchor=(1.02, 1), loc="upper left")
            fig.tight_layout()
            fig.savefig(PLOT_DIR / f"{stem}.png", dpi=150, bbox_inches="tight")
            plt.close(fig)

        offset += prediction_c.shape[0]
        print(f"Exported {offset}/{len(datasets)} cases", flush=True)

    summary = pd.DataFrame(summary_rows)
    numeric = [column for column in summary.columns if column != "Case"]
    summary = pd.concat([
        summary, pd.DataFrame([{"Case": "Mean", **summary[numeric].mean().to_dict()}])
    ], ignore_index=True)
    summary.to_csv(SUMMARY_PATH, index=False, float_format="%.6f")

    v7_result, v7_error_curve = finish_stability(v7_stability)
    v8_result, v8_error_curve = finish_stability(v8_stability)
    with open(DIAGNOSTICS_PATH, "w", encoding="utf-8") as handle:
        json.dump({"v7": v7_result, "v8": v8_result}, handle, indent=2)

    time_axis = test_dfs[0][0]["Time (s)"].to_numpy(float)[1:]
    fig, axis = plt.subplots(figsize=(12, 6))
    axis.plot(time_axis, v7_error_curve, label="v7", linewidth=2)
    axis.plot(time_axis, v8_error_curve, label="v8", linewidth=2)
    axis.set(xlabel="Time (s)", ylabel="Mean absolute error (C)", title="Full-test error over forecast horizon")
    axis.grid(True, alpha=0.35)
    axis.legend()
    fig.tight_layout()
    fig.savefig(ERROR_PLOT_PATH, dpi=170)
    plt.close(fig)
    print(f"Finished: {len(datasets)} PNG, {len(datasets)} CSV")


if __name__ == "__main__":
    main()
