# Convection LSTM v8 — Python and model package

这是当前正式 v8 的推理与源码包。模型为 5 层单向 LSTM（hidden=128），含 Initial State Encoder、层注意力及 gated residual TCN。E3 仍是研究候选，本包使用正式 `best_v8.pth`。

## 文件

- `predict_v8.py`：推荐推理入口。复用原模型代码，不需要原训练数据或 v7 权重。
- `Final_LSTM_data522_v2.py`：LSTM、初始状态编码器及数据集定义。
- `Final_LSTM_data522_v6.py`：自回归与主干构造等共享函数。
- `Final_LSTM_data522_v7.py`：v8 的源码导入依赖。
- `Final_LSTM_data522_v8.py`：17 维特征、TCN 和历史适配器训练代码。
- `refine_v8_adapter.py` / `export_v8_test_results.py`：历史精修与结果导出源码，供核对训练及评价流程。
- `Final_LSTM_data522_v8_result/best_v8.pth` / `best_v8_config.json`：正式完整权重及配置。
- `scaler_v8.npz`：从哈希核对后的历史 961 条训练轨迹重建的归一化参数。
- `scaler_provenance.json`：归一化拟合规则、来源与哈希。
- `example_input.csv`：完整示例工况及初始温度，后续目标温度留空。
- `requirements.txt` / `environment.json`：依赖和打包时环境。
- `SHA256SUMS.json`：包内文件校验值。

## 运行

解压后进入这个文件夹，在已有 Python 环境中安装依赖：

```bash
python -m pip install -r requirements.txt
python predict_v8.py --input example_input.csv --output predictions.csv --device cpu
```

有可用 CUDA 环境时，可使用 `--device cuda`。包内记录的是本地环境的包版本；安装 CUDA 版 PyTorch 时还需选择与目标机器相容的构建。命令未自动安装或修改接收方环境。

自己的 CSV 使用以下列名（单位为秒、摄氏度、W/m²°C）：

```text
Time (s),T_outer (C),T_inner (C),T_avg (C),Input Temperature (C),Convection (W/m2C)
```

提供完整时间与工况轨迹，第一行 t=0，并每10秒一个点。三个目标温度列只需第一行的真实初始观测，后续可留空；入口会忽略后续温度值。`T_ave (C)` 也可作为 average 温度列名。示例为1441行，输出1440个预测时刻：输入第 k 行对应输出第 k+1 行。

输出列为 `Time (s)`、`T_inner_Pred (C)`、`T_outer_Pred (C)`、`T_avg_Pred (C)`，全部温度已经反归一化。

## 模型和资料的适用范围

权重自包含 LSTM 与 TCN，不需要额外 v7 权重。归一化参数沿用历史 v8 的训练划分：排序后的1011个来源文件中前50个作验证，余961个拟合 scaler；拟合发生在异常隔离之前。参数经过原数据哈希核对后导出，没有改用 E0/E3 的修正划分。

本模型使用已知的完整输入温度/对流工况计划。GroupNorm 汇总整段轨迹统计，截短轨迹会影响校正结果；原训练轨迹通常覆盖0至14400秒、10秒采样。本入口允许其他长度，但这不代表模型已验证任意预测时长。

历史数据审计发现跨集合重复，部分测试案例已被反复查看；配置文件中的历史分数不是新的独立泛化证据。包内没有训练/测试数据全集，也没有以测试分数选定新模型。

原训练和评价脚本按原项目的目录加载数据及历史 checkpoint。它们为源码归档，直接重新训练还需要原始数据、继承权重和历史启动配置。直接推理请使用 `predict_v8.py`。

## 打包检查

正式权重与原项目基线 SHA256 一致。导出的 scaler 来源961个训练文件均与已有审计清单 SHA256 一致。`verification.json` 记录推理入口检查；它仅验证包的运行与原路径一致性，不产生新的模型性能结论。
