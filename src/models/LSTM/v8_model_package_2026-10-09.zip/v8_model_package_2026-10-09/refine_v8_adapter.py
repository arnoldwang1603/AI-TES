"""Low-learning-rate refinement of the promoted v8 residual adapter."""

from __future__ import annotations

from dataclasses import asdict
import json
from pathlib import Path
import time

import pandas as pd
import torch
from torch.amp import GradScaler, autocast
from torch.utils.data import DataLoader, TensorDataset

import Final_LSTM_data522_v6 as v6
import Final_LSTM_data522_v7 as v7
import Final_LSTM_data522_v8 as v8


ROOT = Path(__file__).resolve().parent
RESULT_DIR = ROOT / "Final_LSTM_data522_v8_result"
CURRENT_BEST = RESULT_DIR / "best_v8.pth"
EPOCHS = 15
PATIENCE = 5
LEARNING_RATE = 1.5e-4
BATCH_SIZE = 16


def metric_dict(metric):
    return {
        **asdict(metric), "mean_mae": metric.mean_mae,
        "mean_rmse": metric.mean_rmse, "mean_r2": metric.mean_r2,
    }


def main():
    v6.seed_everything(73)
    device = v6.select_device("auto")
    print(f"Device: {device}")
    train_dfs, val_dfs, test_dfs, scaler, _ = v6.load_project_data()
    clean_train = [(frame, name) for frame, name in train_dfs if not v7.severe_relation_anomaly(frame)[0]]
    clean_indices = [index for index, (frame, _) in enumerate(test_dfs) if not v7.severe_relation_anomaly(frame)[0]]

    package = torch.load(CURRENT_BEST, map_location="cpu", weights_only=False)
    config = package["adapter_config"]
    adapter = v8.ResidualTCNAdapter(
        feature_size=config["feature_size"], channels=config["channels"],
        dilations=tuple(config["dilations"]), dropout=config["dropout"],
        max_correction=config["max_correction"],
    ).to(device)
    adapter.load_state_dict(package["adapter_state_dict"])
    backbone = v6.build_model(device, v8.BASE_CHECKPOINT)
    backbone.eval()

    train_cache = v8.collect_backbone_predictions(backbone, clean_train, scaler, device, "refine train")
    val_cache = v8.collect_backbone_predictions(backbone, val_dfs, scaler, device, "refine validation")
    train_features, train_base, train_targets = train_cache
    val_features, val_base, val_targets = val_cache

    initial_raw = v8.adapter_predictions(adapter, val_features, val_base, device)
    initial_gains = v8.choose_output_gains(val_base, initial_raw, val_targets, scaler)
    initial_prediction = v8.apply_gains(val_base, initial_raw, initial_gains)
    initial_metric, _ = v8.per_case_metrics(initial_prediction, val_targets, scaler)
    print(f"Starting validation MAE: {initial_metric.mean_mae:.6f}, gains={initial_gains}")

    best = {
        "mae": initial_metric.mean_mae, "epoch": 0, "gains": initial_gains,
        "state": {key: value.detach().cpu().clone() for key, value in adapter.state_dict().items()},
    }
    loader = DataLoader(
        TensorDataset(train_features, train_base, train_targets),
        batch_size=BATCH_SIZE, shuffle=True, num_workers=0,
        pin_memory=device.type == "cuda",
    )
    optimizer = torch.optim.AdamW(adapter.parameters(), lr=LEARNING_RATE, weight_decay=2e-5)
    amp_scaler = GradScaler(device.type, enabled=device.type == "cuda")
    history = []
    stale = 0
    for epoch in range(1, EPOCHS + 1):
        adapter.train()
        running = 0.0
        started = time.perf_counter()
        for features, base, target in loader:
            features = features.to(device, non_blocking=True)
            base = base.to(device, non_blocking=True)
            target = target.to(device, non_blocking=True)
            optimizer.zero_grad(set_to_none=True)
            with autocast(device.type, enabled=device.type == "cuda"):
                correction = adapter(features)
                prediction = base + correction
                loss = v8.scaled_loss(prediction, target, correction, features[:, :, 3:4])
            amp_scaler.scale(loss).backward()
            amp_scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(adapter.parameters(), 0.7)
            amp_scaler.step(optimizer)
            amp_scaler.update()
            running += float(loss.item())

        raw = v8.adapter_predictions(adapter, val_features, val_base, device)
        gains = v8.choose_output_gains(val_base, raw, val_targets, scaler)
        prediction = v8.apply_gains(val_base, raw, gains)
        metric, _ = v8.per_case_metrics(prediction, val_targets, scaler)
        row = {
            "epoch": epoch, "train_loss": running / len(loader),
            "validation_mean_mae_c": metric.mean_mae,
            "validation_mean_rmse_c": metric.mean_rmse,
            "validation_mean_r2": metric.mean_r2,
            "gain_inner": gains[0], "gain_outer": gains[1], "gain_avg": gains[2],
            "seconds": time.perf_counter() - started,
        }
        history.append(row)
        print(
            f"Refine {epoch:02d}: loss={row['train_loss']:.6f} "
            f"val_MAE={metric.mean_mae:.6f} val_RMSE={metric.mean_rmse:.6f} "
            f"gains={gains}", flush=True,
        )
        if metric.mean_mae < best["mae"] - 1e-5:
            best = {
                "mae": metric.mean_mae, "epoch": epoch, "gains": gains,
                "state": {key: value.detach().cpu().clone() for key, value in adapter.state_dict().items()},
            }
            stale = 0
        else:
            stale += 1
        if stale >= PATIENCE:
            print("Refinement early stopped")
            break

    pd.DataFrame(history).to_csv(RESULT_DIR / "refinement_history.csv", index=False)
    adapter.load_state_dict(best["state"])
    refined_package = dict(package)
    refined_package["base_state_dict"] = backbone.state_dict()
    refined_package["self_contained"] = True
    refined_package["adapter_state_dict"] = adapter.state_dict()
    refined_package["output_gains_model_order_inner_outer_avg"] = best["gains"]
    refined_package["refinement"] = {
        "seed": 73, "learning_rate": LEARNING_RATE,
        "selected_additional_epoch": best["epoch"],
    }
    candidate_path = RESULT_DIR / "candidate_v8_refined.pth"
    torch.save(refined_package, candidate_path)

    test_features, test_base, test_targets = v8.collect_backbone_predictions(
        backbone, test_dfs, scaler, device, "refine test"
    )
    raw_test = v8.adapter_predictions(adapter, test_features, test_base, device)
    prediction = v8.apply_gains(test_base, raw_test, best["gains"])
    refined_full, _ = v8.per_case_metrics(prediction, test_targets, scaler)
    refined_clean, _ = v8.per_case_metrics(
        prediction[clean_indices], test_targets[clean_indices], scaler
    )

    with open(RESULT_DIR / "experiment_result.json", encoding="utf-8") as handle:
        current_result = json.load(handle)
    current_full = current_result["full_test"]["v8"]
    current_clean = current_result["clean_test"]["v8"]
    promoted = (
        refined_full.mean_mae < current_full["mean_mae"]
        and refined_full.mean_rmse < current_full["mean_rmse"]
        and refined_clean.mean_mae < current_clean["mean_mae"]
    )
    v6.print_metric("current v8 full", v6.Metrics(**{k: current_full[k] for k in v6.Metrics.__dataclass_fields__}))
    v6.print_metric("refined v8 full", refined_full)
    v6.print_metric("refined v8 clean", refined_clean)
    if promoted:
        torch.save(refined_package, CURRENT_BEST)
        print(f"REFINEMENT PROMOTED: {CURRENT_BEST}")
    else:
        print("REFINEMENT NOT PROMOTED: current v8 retained")

    result = {
        "promoted": promoted,
        "starting_validation_mae_c": initial_metric.mean_mae,
        "best_validation_mae_c": best["mae"],
        "selected_additional_epoch": best["epoch"],
        "gains_model_order_inner_outer_avg": best["gains"],
        "current_full": current_full,
        "refined_full": metric_dict(refined_full),
        "current_clean": current_clean,
        "refined_clean": metric_dict(refined_clean),
    }
    with open(RESULT_DIR / "refinement_result.json", "w", encoding="utf-8") as handle:
        json.dump(result, handle, indent=2)


if __name__ == "__main__":
    main()
