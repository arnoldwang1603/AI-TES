"""Predict with the official v8 checkpoint and its exported historical scaler.

The CSV supplies a complete forcing schedule and observed temperatures at row 0.
Temperature values after row 0 are neither required nor read by this entry point.
"""
from __future__ import annotations

import argparse
from pathlib import Path
import numpy as np
import pandas as pd
import torch
import Final_LSTM_data522_v6 as v6
import Final_LSTM_data522_v8 as v8

ROOT = Path(__file__).resolve().parent
FORCING = ["Time (s)", "Input Temperature (C)", "Convection (W/m2C)"]
INITIAL = ["T_outer (C)", "T_inner (C)", "T_avg (C)"]


def prepare_inputs(frame, scaler_path, device):
    frame = frame.rename(columns={"T_ave (C)": "T_avg (C)"})
    if not frame.columns.is_unique:
        raise ValueError("CSV column names must be unique")
    missing = [name for name in FORCING + INITIAL if name not in frame.columns]
    if missing:
        raise ValueError(f"Missing columns: {missing}")
    if len(frame) < 2:
        raise ValueError("At least two time points are required")
    known = frame[FORCING].to_numpy(dtype=np.float64)
    initial_c = frame.loc[frame.index[0], INITIAL].to_numpy(dtype=np.float64)
    if not np.isfinite(known).all() or not np.isfinite(initial_c).all():
        raise ValueError("Forcing and row-0 initial temperatures must be finite")
    if known[0, 0] != 0 or not np.allclose(np.diff(known[:, 0]), 10, rtol=0, atol=1e-6):
        raise ValueError("This checkpoint expects a t=0 start and 10-second sampling")
    # Historical scaler order: time, outer, inner, average, input temperature, convection.
    physical = np.column_stack([known[:, 0], np.tile(initial_c, (len(frame), 1)), known[:, 1:]])
    with np.load(scaler_path, allow_pickle=False) as saved:
        scaled = physical * saved["scale_"] + saved["min_"]
        output_min = saved["data_min_"][[2, 1, 3]].copy()
        output_range = saved["data_range_"][[2, 1, 3]].copy()
    # Match ThermalDataset: x[k] -> target[k+1]; output order inner, outer, average.
    x = torch.as_tensor(scaled[:-1, [0, 1, 2, 4, 3, 5]], dtype=torch.float32, device=device).unsqueeze(0)
    init = torch.as_tensor(scaled[0, [1, 2, 3, 4]], dtype=torch.float32, device=device).unsqueeze(0)
    return x, init, known[1:, 0], output_min, output_range


@torch.inference_mode()
def predict(input_path, output_path, checkpoint_path, scaler_path, device_name="cpu"):
    device = v6.select_device(device_name)
    package = torch.load(checkpoint_path, map_location="cpu", weights_only=False)
    backbone = v6.build_model(device)
    backbone.load_state_dict(package["base_state_dict"], strict=True)
    backbone.eval()
    config = package["adapter_config"]
    adapter = v8.ResidualTCNAdapter(
        feature_size=config["feature_size"], channels=config["channels"],
        dilations=tuple(config["dilations"]), dropout=config["dropout"],
        max_correction=config["max_correction"],
    ).to(device)
    adapter.load_state_dict(package["adapter_state_dict"], strict=True)
    adapter.eval()
    x, initial, times, mins, ranges = prepare_inputs(pd.read_csv(input_path), scaler_path, device)
    base = v6.autoregressive_rollout(backbone, x, initial)
    features = v8.build_features(x, base, initial)
    raw_corrected = base + adapter(features)
    corrected = v8.apply_gains(base, raw_corrected, package["output_gains_model_order_inner_outer_avg"])
    # Same float32 inverse transform as v6.scaled_to_celsius.
    low = torch.as_tensor(mins, device=device, dtype=corrected.dtype)
    span = torch.as_tensor(ranges, device=device, dtype=corrected.dtype)
    temperatures = (corrected * span + low)[0].cpu().numpy()
    if not np.isfinite(temperatures).all():
        raise RuntimeError("Model produced non-finite temperatures")
    result = pd.DataFrame({"Time (s)": times,
                           "T_inner_Pred (C)": temperatures[:, 0],
                           "T_outer_Pred (C)": temperatures[:, 1],
                           "T_avg_Pred (C)": temperatures[:, 2]})
    output_path = Path(output_path)
    if output_path.resolve() == Path(input_path).resolve():
        raise ValueError("Output must differ from input CSV")
    output_path.parent.mkdir(parents=True, exist_ok=True)
    result.to_csv(output_path, index=False)
    print(f"Saved {len(result)} predicted time points to {output_path}")
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, default=Path("predictions.csv"))
    parser.add_argument("--checkpoint", type=Path, default=ROOT / "Final_LSTM_data522_v8_result/best_v8.pth")
    parser.add_argument("--scaler", type=Path, default=ROOT / "scaler_v8.npz")
    parser.add_argument("--device", choices=["cpu", "cuda", "auto"], default="cpu")
    parser.add_argument("--threads", type=int, default=1)
    args = parser.parse_args()
    if args.threads < 1:
        parser.error("--threads must be positive")
    torch.set_num_threads(args.threads)
    predict(args.input, args.output, args.checkpoint, args.scaler, args.device)
